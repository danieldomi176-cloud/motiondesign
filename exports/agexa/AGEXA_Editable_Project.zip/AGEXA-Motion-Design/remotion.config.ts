import {Config} from '@remotion/cli/config';
Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
Config.setBrowserExecutable(process.env.REMOTION_BROWSER_EXECUTABLE || process.env.BROWSER_EXECUTABLE || '/usr/bin/chromium');
