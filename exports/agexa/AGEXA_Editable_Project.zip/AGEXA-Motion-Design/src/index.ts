import {registerRoot} from 'remotion';
import {AgexaCompositions} from './agexa/Compositions';
registerRoot(AgexaCompositions);
