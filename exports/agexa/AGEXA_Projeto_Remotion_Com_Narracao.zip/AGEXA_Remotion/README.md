# Agexa — anúncio de 55 segundos

Projeto editável em Remotion, com modelos 3D originais de Blender e banda sonora sintetizada para este anúncio. Vertical 1080 × 1920, 30 fps, 1650 frames.

## Abrir e renderizar

```bash
npm ci
npm run studio
npm run check
npm run render
```

A prévia está em http://localhost:3000/AGEXA-Anuncio-55s. As seis cenas também podem ser abertas separadamente na pasta Cenas. O comando de render assume Chromium em `/usr/bin/chromium`; adaptar `remotion.config.ts` e o comando se necessário. No fim, Python e FFmpeg normalizam a exportação para H.264 yuv420p, BT.709, faixa limitada e faststart. Código e fontes estão incluídos, sem dependência de URLs de assets durante o render.

## Estado dos materiais

**Esta é uma versão ilustrativa renderizada com narração.** Não foram encontrados ficheiros fornecidos do Agexa, logótipo original, capturas do produto, gravações de ecrã ou voz do Rogério. Nenhum material de outra marca chamada Agexa foi usado.

- O nome Agexa no fecho é texto provisório, **não o logótipo original**. Copiar o original para `public/brand/logo-original.png` e indicar esse caminho em `src/settings.tsx`.
- Todas as interfaces estão identificadas no vídeo como **Interface ilustrativa · Dados de demonstração**. Representam apenas o fluxo descrito pelo utilizador; não constituem validação da interface nem das funcionalidades da versão real.
- O MP4 inclui uma voz neural masculina em português de Portugal (`pt-PT-DuarteNeural`), com o roteiro original. Não imita Rogério. O texto e os tempos estão em `Narracao_AGEXA_55s.txt`, e a faixa contínua em `public/audio/narracao.wav`. `src/settings.tsx` já ativa a narração.

## Marcação única de demonstração

| Campo | Valor em todo o vídeo |
|---|---|
| Negócio fictício | Barbearia Demo |
| Cliente fictício | Cliente Demo |
| Serviço | Corte clássico |
| Profissional | Mateus |
| Hora | 15:00 / 15h |
| Duração ilustrativa | 30 minutos |
| Dia | Hoje · Dia de demonstração |
| WhatsApp comercial fornecido | +258 84 671 1987 |

Os textos do cartão partilhado e da agenda vêm de `BOOKING` em `src/design.tsx`. As texturas do telemóvel usam os mesmos valores em `scripts/make-ui.mjs`. Não existem contactos de clientes, métricas, testemunhos, promessas de resultados, cobranças ou parcerias.

## Capturas a substituir

| Ficheiro / cena | Captura real necessária |
|---|---|
| `public/ui/link.png` / 6–9.5 s | Ação de partilhar o link do negócio |
| `public/ui/service.png` / 9.5–15.5 s | Página do negócio e serviço Corte clássico selecionado |
| `public/ui/professional.png` / 15.5–18 s | Seleção do profissional Mateus |
| `public/ui/time.png` / 18–20.7 s | Disponibilidade com 15:00 selecionado |
| `public/ui/review.png` / 20.7–23.4 s | Resumo anterior à confirmação |
| `public/ui/confirmed.png` / 23.4–26.5 s | Confirmação da mesma marcação |
| `Calendar` em `src/design.tsx` / 25–48 s | Agenda real do Agexa Business com a mesma marcação |

Preparar as capturas do cliente a 720 × 1429, sem contactos reais. O modelo aplica cada PNG como **textura UV do ecrã**. Recriar as placas com `blender -b -t 3 -P blender/build_assets.py -- phone`. O script carrega cada textura por caminho relativo ao projeto. O cartão destacado é uma camada separada no Remotion para a transição por correspondência. Ajustar a posição à captura final. Substituir a agenda ilustrativa por uma captura real, preservando a camada do mesmo cartão na transição. Retirar os avisos de interface ilustrativa apenas depois de substituir e validar os ecrãs reais.

Para recriar todos os assets: `node scripts/make-ui.mjs` (necessita DejaVu Sans) e `blender -b -t 3 -P blender/build_assets.py`. Os ficheiros `.blend` contêm os modelos editáveis; o script Python é a fonte de reprodução e reaplica as texturas de `public/ui`.

## Som e legendas

`public/audio/musica.wav` e `efeitos.wav` são faixas separadas de 55 s, estéreo, 48 kHz. `mistura_sem_voz.wav` conserva a referência anterior. A música original usa síntese determinística; não contém samples de terceiros. Há duas notificações, pausa antes da solução, toques, mudança musical na confirmação e transição de encaixe.

A narração neural está em `public/audio/narracao.wav`, mono, 48 kHz, PCM de 24 bits, normalizada para aproximadamente -16 LUFS. A voz usa português de Portugal e preserva a entoação das seis leituras completas, com as pausas posicionadas através das fronteiras de palavras. `narracao-alinhamento.json` regista os tempos exatos. `musica_voz.wav` reduz a música durante a fala e recupera suavemente nas pausas; os efeitos ficam a 72% do nível original.

O Remotion faz a mistura das três faixas. Para atualizar só o som, preservando os frames existentes: `npm run update:voice`. Para recriar a síntese: instalar `edge-tts==7.3.1`, executar `scripts/generate-voice.py` com acesso à rede, e depois `scripts/assemble-voice.py` com NumPy, SciPy e FFmpeg. Os ficheiros necessários já estão incluídos; não é necessário acesso à síntese para abrir ou renderizar o projeto.

`scripts/make-audio.py` recria o som com Python, NumPy e SciPy. As legendas estão em arrays editáveis em cada cena, no formato Caption, com no máximo duas linhas. Existe uma cópia JSON e SRT nos entregáveis. A área principal ocupa x=90–910 e as legendas ficam acima dos controlos inferiores. O fecho fica estável por mais de quatro segundos, com somente o nome provisório e as três linhas solicitadas.

## Estrutura

- `src/Film.tsx`: seis cenas e três faixas de áudio independentes (voz, música e efeitos).
- `src/scenes`: composição editável de cada cena, animações baseadas em frames.
- `src/design.tsx`: tipografia, materiais de vidro, telemóvel, cartão e agenda.
- `src/settings.tsx`: pontos de entrada para o logótipo e a voz reais.
- `public/3d`: renders transparentes de modelos 3D, sem geração de imagens por IA.
- `blender`: fontes editáveis do telemóvel, relógio e objetos setoriais.
- `out/AGEXA_Anuncio_55s.mp4`: export final desta versão ilustrativa.

Consultar `VALIDACAO.md` para os resultados das verificações do ficheiro entregue.
