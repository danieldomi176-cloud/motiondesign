# Validação do anúncio Agexa

## Exportação e integridade

- Ficheiro: `AGEXA_Anuncio_55s.mp4`.
- Duração: **55.000000 segundos**, **1650 frames**, **30 fps**.
- Imagem: **1080 × 1920**, vertical 9:16, H.264, yuv420p.
- Áudio: AAC, estéreo, 48 kHz. **Narração neural em português de Portugal**, música e efeitos.
- Tamanho: 5.49 MiB.
- FFmpeg descodificou o ficheiro completo, vídeo e áudio, sem erros (`-xerror`).
- Abertura em Chromium e reprodução confirmadas a 360 × 640. O tempo avançou e foram descodificados frames nos pontos 0 s, 24 s, 26 s, 43 s e 52 s. Sem erros de media.
- SHA-256: `b5078afbe04672a89035e6397cfbe8007380b77404340805d8d116abcfafceb2`.

## Revisão visual

Foram revistos enquadramentos em 360 × 640 e renders de amostra de todas as cenas. A cadeia conserva **Corte clássico → Mateus → 15:00**. A mesma camada de cartão passa da confirmação para a agenda. O contacto do fecho é **+258 84 671 1987**. As duas notificações e os toques acompanham as ações; existe silêncio antes da solução e uma mudança musical mais leve na confirmação.

As legendas foram medidas com a fonte Manrope a 44 px: no máximo duas linhas; largura máxima 697 px numa área interna de 764 px. Posição x=90–910, acima da zona inferior dos controlos sociais. Os passos e a agenda foram mantidos quase de frente para leitura.

O fecho estabiliza a partir de 49.1 s. A última legenda adicional termina em 50.85 s, deixando **4.15 s** finais apenas com o nome Agexa provisório, o símbolo de WhatsApp e as três linhas solicitadas.

## Narração e mistura

A voz masculina é `pt-PT-DuarteNeural`, uma voz neural genérica em português de Portugal. Não é a voz do Rogério nem uma imitação. O roteiro foi integralmente mantido, com 95 palavras. As fronteiras de palavras fornecidas pelo sintetizador foram usadas para alinhar os 18 trechos às legendas e às ações, numa única faixa contínua de 55 segundos. A fala termina em 53.25 s, deixando o contacto final em ecrã.

A faixa mono da voz mede **-16.78 LUFS** e **-2 dBTP**. A música baixa durante cada trecho de fala, com ataque de 65 ms e recuperação de 420 ms; os efeitos ficam a 72% do nível anterior. A voz ficou entre **17.3 e 26.3 dB** acima da música em RMS nos 18 trechos. O MP4 final mede **-14.01 LUFS**, com pico verdadeiro de **-1.51 dBTP**, sem clipping.

O Remotion renderizou a mistura das três faixas, e o áudio substituiu a mistura anterior no MP4 preservando os frames H.264. O hash do fluxo de vídeo antes e depois coincide: `923249783ca8261a35fdaafd0557c5cce12b5e53a54be176e879718107542fc0`. Os metadados do sintetizador confirmam a presença das 95 palavras do roteiro; a transcrição automática foi usada como verificação auxiliar.

## Materiais em falta

Não foram fornecidos o logótipo original, as capturas reais do produto nem a voz do Rogério. O MP4 é uma **versão ilustrativa**, com as telas identificadas em ecrã. O nome Agexa é texto provisório, não uma recriação do logótipo. Os pontos de substituição estão no README e em `src/settings.tsx`.

Não é possível confirmar a correspondência com a interface real sem receber as capturas. A voz neural está incorporada e a música e os efeitos continuam em faixas separadas. A eventual gravação do Rogério pode substituir a voz atual em `src/settings.tsx`.

## Projeto editável

TypeScript passou (`npm run check`). As seis cenas estão registadas no Remotion Studio e a prévia foi aberta. Incluem-se fontes, texturas, scripts de síntese e seis ficheiros Blender editáveis com as imagens necessárias incorporadas. O ZIP é verificado com `testzip()` durante a embalagem.
