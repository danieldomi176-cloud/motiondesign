"""Modelos originais para o anúncio Agexa. Reexecutar: blender -b -t 3 -P blender/build_assets.py.
As imagens de public/ui são TEXTURAS reais do ecrã 3D. Substituir por capturas autorizadas.
"""
import bpy, math, os, sys
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'public','3d'); os.makedirs(OUT,exist_ok=True)
ONLY=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
def mat(name,color,metal=0,rough=.28,trans=0):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1); p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough; p.inputs['Transmission Weight'].default_value=trans
 p.inputs['Coat Weight'].default_value=.4; p.inputs['Coat Roughness'].default_value=.13
 return m
def box(name,loc,scale,material,bevel=.12):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.name=name; o.dimensions=scale; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=o.modifiers.new('Arestas arredondadas','BEVEL'); mod.width=bevel; mod.segments=6
  o.modifiers.new('Normais ponderadas','WEIGHTED_NORMAL')
 if material:o.data.materials.append(material)
 return o
def cyl(name,loc,r,depth,material,rotation=(0,0,0)):
 bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=r,depth=depth,location=loc,rotation=rotation); o=bpy.context.object; o.name=name; o.data.materials.append(material)
 b=o.modifiers.new('Borda macia','BEVEL');b.width=.045;b.segments=4;o.modifiers.new('Normais','WEIGHTED_NORMAL')
 for p in o.data.polygons:p.use_smooth=True
 return o
def torus(name,loc,major,minor,material,rotation=(0,0,0)):
 bpy.ops.mesh.primitive_torus_add(major_segments=96,minor_segments=20,location=loc,major_radius=major,minor_radius=minor,rotation=rotation);o=bpy.context.object;o.name=name;o.data.materials.append(material)
 for p in o.data.polygons:p.use_smooth=True
 return o
def rounded(name,loc,scale,material,r):
 w,h,d=scale; verts=[]; n=17*4
 for z in [-d/2,d/2]:
  for cx,cy,start in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
   for j in range(17):
    a=math.radians(start+j*90/16);verts.append((cx+r*math.cos(a),cy+r*math.sin(a),z))
 faces=[list(reversed(range(n))),list(range(n,n*2))]+[(j,(j+1)%n,(j+1)%n+n,j+n) for j in range(n)]
 m=bpy.data.meshes.new(name);m.from_pydata(verts,[],faces);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);o.location=loc;o.data.materials.append(material)
 mod=o.modifiers.new('Chanfrein','BEVEL');mod.width=.018;mod.segments=3;o.modifiers.new('Normais','WEIGHTED_NORMAL')
 return o
def area(loc,power,size,color):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler()
def setup(w,h,ortho=5,camera=(0,0,12)):
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.cycles.max_bounces=5
 s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.render.film_transparent=True
 s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='8'
 s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.13,.21,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.6
 s.view_settings.view_transform='Standard';s.view_settings.look='Medium High Contrast';s.view_settings.exposure=0;s.view_settings.gamma=1
 bpy.ops.object.camera_add(location=camera);o=bpy.context.object;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler();o.data.type='ORTHO';o.data.ortho_scale=ortho;s.camera=o
 area((-4,3,7),850,5,(.84,.87,1));area((4,1,3),1100,3,(.52,.28,1));area((0,-5,6),600,4,(1,1,1))
 return s
black=mat('Grafite anodizado',(.045,.043,.058),.8,.19)
purple=mat('Roxo demonstrativo Agexa',(.39,.16,.8),.45,.22)
silver=mat('Metal branco',(.72,.75,.84),.82,.19)
white=mat('Cerâmica branca',(.86,.83,.92),.12,.24)
dark=mat('Vidro preto',(.007,.006,.013),.25,.16)
glass=mat('Liquid Glass',(.37,.22,.64),.1,.12,.65)
def render(name):
 if 'no-render' in ONLY:return
 bpy.context.scene.render.filepath=os.path.join(OUT,name+'.png');bpy.ops.render.render(write_still=True)
def phone():
 s=setup(720,1400,7.6)
 rounded('Corpo de titânio',(0,0,0),(3.65,7.0,.32),black,.34)
 rounded('Aro polido',(0,0,.13),(3.59,6.94,.12),silver,.32)
 rounded('Moldura de vidro',(0,0,.195),(3.54,6.89,.09),dark,.29)
 # Tela arredondada com coordenadas UV explícitas, fiel ao tamanho da captura.
 w,h,r=3.35,6.65,.22; verts=[]
 for cx,cy,start in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
  for j in range(17):
   a=math.radians(start+j*90/16);verts.append((cx+r*math.cos(a),cy+r*math.sin(a),.247))
 mesh=bpy.data.meshes.new('Ecrã UV');mesh.from_pydata(verts,[],[list(range(len(verts)))]);mesh.uv_layers.new(name='UVMap')
 for poly in mesh.polygons:
  for li in poly.loop_indices:
   v=verts[mesh.loops[li].vertex_index];mesh.uv_layers.active.data[li].uv=((v[0]+w/2)/w,(v[1]+h/2)/h)
 o=bpy.data.objects.new('Ecrã • textura substituível',mesh);bpy.context.collection.objects.link(o)
 m=bpy.data.materials.new('Captura do Agexa');m.use_nodes=True;n=m.node_tree.nodes;n.clear();out=n.new('ShaderNodeOutputMaterial');e=n.new('ShaderNodeEmission');e.inputs['Strength'].default_value=.95;im=n.new('ShaderNodeTexImage');m.node_tree.links.new(im.outputs['Color'],e.inputs['Color']);m.node_tree.links.new(e.outputs[0],out.inputs['Surface']);o.data.materials.append(m)
 rounded('Ilha da câmara',(0,3.02,.27),(.99,.20,.06),dark,.095)
 cyl('Lente frontal',(.31,3.02,.308),.058,.025,black)
 box('Botão lateral',(1.84,.82,0),(.06,.74,.16),silver,.025)
 box('Volume +',(-1.84,1.2,0),(.06,.44,.16),black,.025)
 box('Volume -',(-1.84,.62,0),(.06,.44,.16),black,.025)
 bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Telemovel.blend'))
 for stage in ['idle','link','service','professional','time','review','confirmed']:
  im.image=bpy.data.images.load(os.path.join(ROOT,'public','ui',stage+'.png'),check_existing=True)
  render('phone-'+stage)
 # Um ângulo de apresentação; os planos informativos usam o frontal acima.
 s.camera.location=(2,-.5,14);s.camera.rotation_euler=(-s.camera.location).to_track_quat('-Z','Y').to_euler();im.image=bpy.data.images.load(os.path.join(ROOT,'public','ui','idle.png'),check_existing=True);render('phone-angle')
 bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Telemovel.blend'))
def clock():
 setup(600,600,4.5)
 cyl('Relógio — corpo',(0,0,0),1.73,.35,black)
 torus('Aro polido',(0,0,.2),1.64,.1,silver)
 cyl('Mostrador',(0,0,.23),1.53,.08,dark)
 torus('Reflexo roxo',(0,0,.3),1.48,.025,purple)
 for i in range(12):
  a=i*math.pi/6;o=box('Índice %02d'%i,(math.sin(a)*1.28,math.cos(a)*1.28,.31),(.055,.19,.035),white,.018);o.rotation_euler[2]=-a
 cyl('Eixo',(0,0,.43),.11,.08,purple)
 render('clock');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Relogio.blend'))
def sectors():
 setup(640,640,4.4,(3,-4,10))
 box('Máquina — corpo',(0,-.3,0),(1.25,2.45,.75),purple,.3)
 box('Painel',(0,-.25,.4),(.9,1.7,.09),black,.2)
 box('Lâmina',(0,1.1,.15),(1.45,.55,.4),silver,.08)
 for x in range(13):box('Dente %02d'%x,(-.66+x*.11,1.43,.17),(.065,.4,.23),silver,.022)
 cyl('Botão',(0,-.2,.49),.21,.065,silver)
 torus('Energia',(0,-.2,.535),.12,.02,purple)
 render('clipper');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Sectores.blend'))
 setup(640,640,4.7,(3,-4,10))
 cyl('Corpo do secador',(-.2,.55,0),.67,1.8,purple,(0,math.pi/2,0))
 cyl('Entrada traseira',(-1.12,.55,0),.58,.08,black,(0,math.pi/2,0))
 torus('Aro traseiro',(-1.18,.55,0),.55,.04,silver,(0,math.pi/2,0))
 cyl('Bocal',(1,.55,0),.38,.7,black,(0,math.pi/2,0))
 o=box('Pega',(-.27,-.65,0),(.6,1.8,.6),black,.18);o.rotation_euler[2]=-.18
 box('Interruptor',(-.16,-.58,.32),(.18,.42,.08),purple,.06)
 render('dryer');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Secador.blend'))
 setup(640,640,4.6,(3,-4,10))
 box('Toalha dobrada',(0,-.5,-.24),(2.7,1.6,.44),white,.2)
 box('Vinco superior',(0,-.46,-.01),(2.63,1.5,.09),white,.1)
 cyl('Toalha enrolada',(0,.35,.47),.65,2.45,white,(0,math.pi/2,0))
 for i in range(5):torus('Dobras do tecido',(1.25,.35,.47),.10+i*.105,.025,white,(0,math.pi/2,0))
 box('Faixa roxa',(0,-.5,.06),(.45,1.5,.07),purple,.03)
 render('towel');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Spa.blend'))
 setup(640,640,4.4,(2,-3,10))
 torus('Anel de consulta',(0,0,-.12),1.65,.09,glass)
 box('Símbolo consulta vertical',(0,0,.15),(.75,2.5,.5),purple,.16)
 box('Símbolo consulta horizontal',(0,0,.16),(2.5,.75,.5),purple,.16)
 box('Brilho vertical',(0,0,.43),(.39,1.9,.03),white,.08)
 box('Brilho horizontal',(0,0,.44),(1.9,.39,.03),white,.08)
 render('consultation');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'blender','Agexa_Consulta.blend'))
if not ONLY or 'phone' in ONLY:phone()
if not ONLY or 'clock' in ONLY:clock()
if not ONLY or 'sectors' in ONLY:sectors()
print('ASSETS 3D CONCLUÍDOS',flush=True)
