"""Monta uma faixa contínua de 55 s e prepara ducking para a música.
Usa as fronteiras de palavras da síntese para manter cada frase no passo certo.
Não corta fonemas entre cenas e conserva a entoação das leituras completas.
"""
from pathlib import Path
import json,subprocess,io
import numpy as np
from scipy.io import wavfile

ROOT=Path(__file__).resolve().parents[1];AUDIO=ROOT/'public/audio';VOICE=AUDIO/'voice';SR=48000
OUT=ROOT/'out/voice-edit';OUT.mkdir(parents=True,exist_ok=True)
# fonte, primeira palavra, última palavra, entrada, velocidade, fim máximo da fala
PLAN=[
 ('01-dor',0,4,.08,1.0,1.65),
 ('01-dor',5,11,1.82,.97,4.35),
 ('01-dor',12,13,4.48,.96,5.32),
 ('02-solucao',0,8,6.06,.92,8.95),
 ('02-solucao',9,16,9.38,.83,12.82),
 ('03-marcacao',0,2,13.05,.88,15.35),
 ('03-marcacao',3,4,15.68,.88,17.85),
 ('03-marcacao',5,8,18.13,.87,20.55),
 ('03-marcacao',9,12,21.42,.86,24.65),
 ('04-agenda',0,7,24.94,.82,29.35),
 ('04-agenda',8,10,29.7,.83,32.35),
 ('04-agenda',11,13,32.65,.86,34.4),
 ('04-agenda',14,17,34.65,.84,37.7),
 ('05-sectores',0,9,38.04,.82,42.08),
 ('05-sectores',10,14,42.16,.82,44.72),
 ('05-sectores',15,20,44.9,.85,47.77),
 ('06-cta',0,6,48.02,.82,50.84),
 ('06-cta',7,11,51.06,.80,54.7),
]
full=np.zeros(55*SR,dtype=np.float64);aligned=[];segments=[]
cache={}
for n,(source,first,last,start,tempo,deadline) in enumerate(PLAN):
 if source not in cache:
  meta=json.loads((VOICE/(source+'.json')).read_text())
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(VOICE/(source+'.mp3')),'-ar',str(SR),'-ac','1','-f','f32le','-'])
  cache[source]=(meta,np.frombuffer(raw,dtype='<f4').copy())
 meta,raw=cache[source];words=meta['words']
 left=words[first]['offset']/1e7-.045
 right=(words[last]['offset']+words[last]['duration'])/1e7+.105
 if first>0:
  prev=(words[first-1]['offset']+words[first-1]['duration'])/1e7
  left=max(left,(prev+words[first]['offset']/1e7)/2)
 if last+1<len(words):
  nxt=words[last+1]['offset']/1e7
  right=min(right,((words[last]['offset']+words[last]['duration'])/1e7+nxt)/2)
 left=max(left,0);clip=raw[round(left*SR):round(right*SR)]
 tmp=OUT/f'{n:02}-source.wav';wavfile.write(tmp,SR,clip.astype(np.float32))
 processed=subprocess.check_output(['ffmpeg','-v','error','-i',str(tmp),'-af',f'atempo={tempo}','-ar',str(SR),'-ac','1','-f','f32le','-'])
 clip=np.frombuffer(processed,dtype='<f4').astype(np.float64)
 # Microfades de 4 ms removem estalidos e mantêm os ataques das palavras intactos.
 fade=min(round(.004*SR),len(clip)//3)
 clip[:fade]*=np.linspace(0,1,fade);clip[-fade:]*=np.linspace(1,0,fade)
 assert start+len(clip)/SR<=deadline+.03,(source,first,last,start+len(clip)/SR,deadline)
 i=round(start*SR);full[i:i+len(clip)]+=clip
 for w in words[first:last+1]:
  a=start+(w['offset']/1e7-left)/tempo;b=a+w['duration']/1e7/tempo
  aligned.append({'text':w['text'],'startMs':round(a*1000),'endMs':round(b*1000),'timestampMs':round((a+b)*500),'confidence':None})
 segments.append({'scene':source,'text':' '.join(w['text'] for w in words[first:last+1]),'start':start,'end':round(start+len(clip)/SR,3),'tempo':tempo})
 print(f'{start:5.2f}–{start+len(clip)/SR:5.2f}',segments[-1]['text'],flush=True)
rawpath=OUT/'narracao-raw.wav';wavfile.write(rawpath,SR,full.astype(np.float32))
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(rawpath),'-af','highpass=f=70,lowpass=f=10500,loudnorm=I=-16:TP=-2:LRA=9','-ar',str(SR),'-ac','1','-c:a','pcm_s24le',str(AUDIO/'narracao.wav')],check=True)
# Envelope obtido da faixa real: ataque 65 ms, libertação 420 ms e margem antes da fala.
duck=np.full(55*SR,.96,dtype=np.float64)
for s in segments:
 a=max(0,round((s['start']-.11)*SR));b=min(len(duck),round((s['end']+.06)*SR))
 attack_start=max(0,a-round(.065*SR));release_end=min(len(duck),b+round(.42*SR))
 duck[attack_start:a]=np.minimum(duck[attack_start:a],np.linspace(.96,.49,a-attack_start))
 duck[a:b]=np.minimum(duck[a:b],.49)
 duck[b:release_end]=np.minimum(duck[b:release_end],np.linspace(.49,.96,release_end-b))
msr,music=wavfile.read(AUDIO/'musica.wav');assert msr==SR
music=music.astype(np.float64)/(2**15)
wavfile.write(AUDIO/'musica_voz.wav',SR,np.int16(np.clip(music*duck[:,None],-1,1)*32767))
alignment={'voice':'pt-PT-DuarteNeural','language':'pt-PT','synthetic':True,'duration':55,'segments':segments,'words':aligned}
(AUDIO/'narracao-alinhamento.json').write_text(json.dumps(alignment,ensure_ascii=False,indent=2))
print('Faixa final: public/audio/narracao.wav; música com ducking: public/audio/musica_voz.wav',flush=True)
