"""Normaliza o MP4 Remotion/JPEG full-range para H.264 BT.709 limitado e duração exata."""
from pathlib import Path
import json,subprocess,sys,os
p=Path(sys.argv[1] if len(sys.argv)>1 else 'out/AGEXA_Anuncio_55s.mp4')
tmp=p.with_name(p.stem+'.normalizado.mp4')
v=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(p)],text=True))['streams'][0]
filters='scale=in_range=full:out_range=limited:in_color_matrix=bt601:out_color_matrix=bt709' if v.get('color_range')=='pc' else 'scale=out_color_matrix=bt709:out_range=limited'
cmd=['ffmpeg','-hide_banner','-y','-i',str(p),'-map','0:v:0','-map','0:a:0','-vf',filters,'-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','aac','-b:a','192k','-ar','48000','-af','atrim=duration=55,asetpts=PTS-STARTPTS','-t','55','-movflags','+faststart',str(tmp)]
subprocess.run(cmd,check=True)
os.replace(tmp,p)
print('MP4 normalizado:',p)
