"""Narração neural genérica em português de Portugal. Não imita Rogério.
Recriar: pip install edge-tts==7.3.1 && python scripts/generate-voice.py
Só envia o texto público do anúncio ao serviço de síntese.
"""
import asyncio,json,os
from pathlib import Path
import edge_tts
import edge_tts.communicate

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'public/audio/voice';OUT.mkdir(parents=True,exist_ok=True)
proxy_certificate=os.environ.get('CODEX_PROXY_CERT')
if proxy_certificate and Path(proxy_certificate).exists():
 edge_tts.communicate._SSL_CTX.load_verify_locations(proxy_certificate)
SCENES=[
 ('01-dor','Estás a atender um cliente. Entretanto, três pessoas perguntam se tens vaga. Quem responde?','+12%'),
 ('02-solucao','Com o Agexa, partilhas um link do teu negócio. O cliente abre-o e vê os horários disponíveis.','+6%'),
 ('03-marcacao','Escolhe o serviço, o profissional e uma hora livre. Depois confirma a marcação.','-4%'),
 ('04-agenda','Do teu lado, essa marcação aparece na agenda. Sabes quem vem, a que horas e qual serviço pediu.','-4%'),
 ('05-sectores','Tens uma barbearia, um salão, um spa ou uma clínica? Podes organizar os teus serviços, profissionais e horários no mesmo painel.','+0%'),
 ('06-cta','Queres ver como ficaria no teu negócio? Pede uma demonstração pelo WhatsApp.','-2%'),
]
async def generate(name,text,rate):
 path=OUT/(name+'.mp3');meta=OUT/(name+'.json')
 if path.exists() and meta.exists():
  print('Existente',name,flush=True);return
 c=edge_tts.Communicate(text,voice='pt-PT-DuarteNeural',rate=rate,boundary='WordBoundary',proxy=os.environ.get('HTTPS_PROXY'),receive_timeout=30)
 boundaries=[]
 with path.open('wb') as f:
  async for chunk in c.stream():
   if chunk['type']=='audio':f.write(chunk['data'])
   elif chunk['type']=='WordBoundary':boundaries.append(chunk)
 meta.write_text(json.dumps({'voice':'pt-PT-DuarteNeural','language':'pt-PT','synthetic':True,'text':text,'rate':rate,'words':boundaries},ensure_ascii=False,indent=2))
 print('Gerada',name,len(boundaries),'palavras',flush=True)
async def main():
 # Duas chamadas simultâneas; cada cena conserva a prosódia de uma leitura completa.
 for i in range(0,len(SCENES),2):await asyncio.gather(*(generate(*s) for s in SCENES[i:i+2]))
asyncio.run(main())
