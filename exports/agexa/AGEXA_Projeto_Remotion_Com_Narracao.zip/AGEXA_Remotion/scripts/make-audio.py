"""Banda sonora ORIGINAL, síntese determinística. Sem gravações ou samples externos.
48 kHz estéreo. A música está baixa para receber narração a cerca de -16 LUFS.
"""
from pathlib import Path
import numpy as np
from scipy.io.wavfile import write
from scipy.signal import butter,sosfilt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'public'/'audio';OUT.mkdir(parents=True,exist_ok=True)
SR=48000;N=55*SR;rng=np.random.default_rng(258)
music=np.zeros((N,2),dtype=np.float64);sfx=np.zeros_like(music)
def add(dst,sig,at,pan=0):
 i=round(at*SR);z=min(len(sig),N-i)
 if z<=0:return
 dst[i:i+z,0]+=sig[:z]*np.sqrt((1-pan)/2);dst[i:i+z,1]+=sig[:z]*np.sqrt((1+pan)/2)
def hz(n):return 440*2**((n-69)/12)
def tone(freq,duration,amp=.05,attack=.02,release=.25,pure=False):
 t=np.arange(round(duration*SR))/SR
 a=np.minimum(t/attack,1)*np.minimum((duration-t)/release,1)
 a=np.maximum(a,0)**1.3
 y=np.sin(2*np.pi*freq*t)
 if not pure:y+=.18*np.sin(2*np.pi*freq*2*t)+.06*np.sin(2*np.pi*freq*3*t)
 return y*a*amp
def pad(notes,at,dur,amp=.012):
 for j,n in enumerate(notes):
  add(music,tone(hz(n),dur,amp,.7,.9),at,(j-(len(notes)-1)/2)*.35)
pad([42,49,57],0,5.2,.016)
for at in np.arange(6,54,4):
 notes=([42,57,61,64],[38,54,57,61],[45,57,61,64],[40,56,59,64])[int((at-6)/4)%4] if at<23.4 else ([45,57,61,64],[49,56,61,64],[38,54,57,61],[40,56,59,64])[int((at-23.4)/4)%4]
 pad(notes,at,min(4.7,55-at),.010 if at<23.4 else .013)
for at in np.arange(6,54.4,1):
 t=np.arange(round(.32*SR))/SR;phase=2*np.pi*(48*t+38*.025*(1-np.exp(-t/.025)));kick=np.sin(phase)*np.exp(-t*18)*.09
 add(music,kick,at)
 add(music,tone(hz(42 if at<23.4 else 45),.48,.03,.008,.4),at+.02)
 if int(at)%2:
  noise=rng.normal(0,1,round(.09*SR));noise=sosfilt(butter(2,1800,fs=SR,btype='highpass',output='sos'),noise)*np.exp(-np.arange(len(noise))/SR*55)*.022
  add(music,noise,at+.5,.18)
for at in np.arange(6.5,54,.5):
 noise=rng.normal(0,1,round(.04*SR));noise=sosfilt(butter(2,6500,fs=SR,btype='highpass',output='sos'),noise)*np.exp(-np.arange(len(noise))/SR*100)*.009
 add(music,noise,at,(-1 if round(at*2)%2 else 1)*.35)
for j,at in enumerate(np.arange(24,53.5,1.5)):
 n=[76,73,69,73,76,80,76,73][j%8];sig=tone(hz(n),1.35,.019,.008,1.3,True)*np.exp(-np.arange(round(1.35*SR))/SR*2)
 add(music,sig,at,(-1 if j%2 else 1)*.4)
def notification(at):
 for note,delay in [(81,0),(88,.12)]:
  sig=tone(hz(note),.5,.11,.006,.48,True)*np.exp(-np.arange(round(.5*SR))/SR*4)
  add(sfx,sig,at+delay,.05)
notification(.45);notification(2.95)
def click(at):
 t=np.arange(round(.12*SR))/SR
 sig=np.sin(2*np.pi*(1300*t-2200*t*t))*np.exp(-t*65)*.085
 add(sfx,sig,at,.08)
for at in [8.7,9.5,14.5,17,19.2,23.1]:click(at)
def chime(at,notes=[73,76,81]):
 for j,n in enumerate(notes):
  dur=1.7;t=np.arange(round(dur*SR))/SR
  sig=tone(hz(n),dur,.09,.008,1.6,True)*np.exp(-t*2)
  add(sfx,sig,at+j*.1,(j-1)*.3)
chime(23.4)
def whoosh(at,dur=.65):
 t=np.arange(round(dur*SR))/SR
 sig=sosfilt(butter(2,[500,3000],btype='bandpass',fs=SR,output='sos'),rng.normal(0,1,len(t)))*np.sin(np.pi*t/dur)**2*.055
 add(sfx,sig,at,-.15)
whoosh(6,.5);whoosh(25.1,.8);whoosh(48,.6)
for at in [38.35,39.6,40.55,41.25]:
 t=np.arange(round(.13*SR))/SR;add(sfx,np.sin(2*np.pi*(800*t-1500*t*t))*np.exp(-t*40)*.065,at)
chime(48.4,[69,76,81])
# Espaço de silêncio antes da solução; abertura escura e mudança musical na confirmação.
for dst in [music,sfx]:
 dst[round(5.25*SR):6*SR]=0
 fade=np.minimum(np.arange(N)/SR/.025,1)*np.minimum((55-np.arange(N)/SR)/1.1,1)
 dst*=fade[:,None]
 # Reverberação curta e discreta, sem simulação de vozes.
 for delay,gain in [(0.09,.13),(.17,.07),(.29,.04)]:
  n=round(delay*SR);dst[n:]+=dst[:-n,::-1]*gain
 dst[round(5.35*SR):6*SR]=0
music*=2.135
for name,dst in [('musica',music),('efeitos',sfx),('mistura_sem_voz',music+sfx)]:
 write(OUT/(name+'.wav'),SR,np.int16(np.clip(dst,-1,1)*32767))
 print(name,'peak dBFS',round(20*np.log10(np.max(np.abs(dst))),1),'rms dBFS',round(20*np.log10(np.sqrt(np.mean(dst*dst))),1))
