import fs from 'node:fs';
import sharp from 'sharp';
const root = new URL('../public/ui/', import.meta.url);
fs.mkdirSync(root,{recursive:true});
const P='#a077ff', W='#f7f5fc', M='#a8a2b6';
const rect=(x,y,w,h,fill,r=26,stroke='none')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" rx="${r}" stroke="${stroke}" stroke-width="2"/>`;
const text=(x,y,t,size=44,fill=W,weight=500)=>`<text x="${x}" y="${y}" fill="${fill}" font-size="${size}" font-weight="${weight}">${t}</text>`;
const line=(x,y,w)=>`<path d="M${x} ${y}h${w}" stroke="#34303e" stroke-width="2"/>`;
const check=(x,y)=>`<circle cx="${x}" cy="${y}" r="24" fill="${P}"/><path d="M${x-11} ${y}l8 8 15-16" fill="none" stroke="#111016" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>`;
const base=(body)=>`<svg xmlns="http://www.w3.org/2000/svg" width="720" height="1429" viewBox="0 0 720 1429"><defs><linearGradient id="bg" x2=".7" y2="1"><stop stop-color="#201a2c"/><stop offset="1" stop-color="#101015"/></linearGradient><linearGradient id="purple"><stop stop-color="#a984ff"/><stop offset="1" stop-color="#8854ec"/></linearGradient></defs><rect width="720" height="1429" fill="url(#bg)"/><g font-family="DejaVu Sans,sans-serif">${text(48,86,'9:41',27,W,600)}${text(568,86,'••• ▰',23)}${body}<path d="M270 1396h180" stroke="#efebfa" stroke-width="8" stroke-linecap="round"/></g></svg>`;
const header=(step,title)=>text(48,175,'AGEXA',34,P,700)+text(48,258,'Barbearia Demo',50,W,700)+text(48,309,'Exemplo de demonstração',25,M)+line(48,352,624)+text(48,426,step,25,P,700)+text(48,503,title,52,W,700);
const button=(label)=>rect(48,1236,624,106,'url(#purple)',28)+text(87,1305,label,43,'#120c1e',700)+text(598,1305,'→',42,'#120c1e',700);
const tag=(y,label,value)=>text(70,y,label,26,M)+text(70,y+58,value,45,W,700);
const avatar=(x,y,name)=>`<circle cx="${x}" cy="${y}" r="54" fill="#413052"/><circle cx="${x}" cy="${y-13}" r="17" fill="#c9b3eb"/><path d="M${x-31} ${y+31}a31 25 0 0 1 62 0" fill="#c9b3eb"/>`;
const screens={
  idle: base(text(48,235,'Mensagens',53,W,700)+text(48,292,'Enquanto estás a atender…',27,M)+rect(48,390,624,190,'#1b1823',30)+text(90,468,'3 pedidos',62,W,700)+text(90,527,'por responder',38,M)+`<circle cx="360" cy="940" r="180" fill="none" stroke="#2d253c" stroke-width="2"/>`+`<circle cx="360" cy="940" r="140" fill="none" stroke="#2d253c" stroke-width="2"/>`),
  link: base(text(48,175,'AGEXA',34,P,700)+text(48,290,'O teu negócio.',55,W,700)+text(48,360,'Num link.',55,W,700)+rect(48,550,624,390,'#292133',38,'#514060')+text(84,638,'LINK DE AGENDAMENTO',25,P,700)+text(84,730,'Barbearia',59,W,700)+text(84,802,'Demo',59,W,700)+text(84,880,'Página de marcação →',34,M)+button('Partilhar link')),
  service: base(header('01 / SERVIÇO','Escolhe o serviço')+rect(48,568,624,234,'#30243f',30,'#a077ff')+text(82,660,'Corte clássico',57,W,700)+text(82,729,'30 minutos',36,M)+check(617,620)+rect(48,839,624,173,'#1b1822')+text(82,916,'Barba',45,W,600)+text(82,967,'20 minutos',30,M)+button('Continuar')),
  professional: base(header('02 / PROFISSIONAL','Quem te atende?')+rect(48,568,624,234,'#30243f',30,'#a077ff')+avatar(138,680)+text(220,672,'Mateus',60,W,700)+text(220,732,'Profissional',30,M)+check(617,620)+rect(48,850,624,150,'#1b1822')+text(82,918,'Corte clássico',43,W,600)+text(82,967,'Serviço escolhido',28,M)+button('Continuar')),
  time: base(header('03 / HORÁRIO','Escolhe uma hora')+text(48,577,'Hoje · Dia de demonstração',27,M)+rect(48,633,294,126,'#23202c')+text(103,717,'14:00',52,W,600)+rect(366,633,306,126,'#9b6af5',26,'#bd9eff')+text(426,717,'15:00',55,'#100b18',700)+rect(48,787,294,126,'#23202c')+text(103,871,'16:00',52,W,600)+rect(366,787,306,126,'#23202c')+text(426,871,'16:30',52,W,600)+text(48,1029,'Corte clássico',43,W,600)+text(48,1095,'com Mateus',40,M)+button('Continuar')),
  review: base(header('04 / CONFIRMAÇÃO','Está tudo certo?')+rect(48,565,624,573,'#24202e',30,'#51435f')+tag(632,'SERVIÇO','Corte clássico')+line(70,734,578)+tag(789,'PROFISSIONAL','Mateus')+line(70,890,578)+tag(946,'HORÁRIO','Hoje · 15:00')+button('Confirmar marcação')),
  confirmed: base(text(48,175,'AGEXA',34,P,700)+`<circle cx="360" cy="395" r="75" fill="#a077ff"/><path d="M326 395l24 24 49-51" stroke="#150f1e" stroke-width="12" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`+text(134,565,'Marcação',61,W,700)+text(94,640,'confirmada',61,W,700)+text(48,1170,'Guardada na agenda',37,M)+rect(48,1236,624,106,'#24202e',28)+text(218,1305,'Concluído',40,W,700)),
};
for(const [name,svg] of Object.entries(screens)) {
 fs.writeFileSync(new URL(`${name}.svg`,root),svg);
 await sharp(Buffer.from(svg)).png().toFile(new URL(`${name}.png`,root).pathname);
}
console.log('7 telas ilustrativas geradas em public/ui.');
