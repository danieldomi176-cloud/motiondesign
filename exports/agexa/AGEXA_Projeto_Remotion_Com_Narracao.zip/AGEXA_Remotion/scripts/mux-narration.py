"""Atualiza apenas o áudio do MP4, preservando exatamente os frames H.264."""
from pathlib import Path
import subprocess,shutil,os
root=Path(__file__).resolve().parents[1];out=root/'out'
target=out/'AGEXA_Anuncio_55s.mp4';base=out/'AGEXA_Anuncio_55s_sem_voz.mp4'
if not base.exists():shutil.copy2(target,base)
tmp=out/'AGEXA_Anuncio_55s_com_voz.mux.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-i',str(base),'-i',str(out/'AGEXA_Mistura_Com_Voz.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t','55','-movflags','+faststart',str(tmp)],check=True)
os.replace(tmp,target)
print('Áudio com narração incorporado; frames H.264 preservados:',target)
