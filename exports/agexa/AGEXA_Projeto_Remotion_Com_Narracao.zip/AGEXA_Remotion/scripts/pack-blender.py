from pathlib import Path
import bpy
root=Path(__file__).resolve().parents[1]
bpy.context.preferences.filepaths.save_version=0
for file in sorted((root/'blender').glob('*.blend')):
 bpy.ops.wm.open_mainfile(filepath=str(file))
 bpy.ops.file.pack_all()
 bpy.ops.wm.save_as_mainfile(filepath=str(file))
 print('PORTABLE',file.name,'imagens incorporadas',sum(1 for i in bpy.data.images if i.packed_file),flush=True)
