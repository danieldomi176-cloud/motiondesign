"""Arquiva o projeto editável e todos os assets necessários, sem dependências instaladas."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];out=root.parent/'entrega';out.mkdir(exist_ok=True)
target=out/'AGEXA_Projeto_Remotion.zip'
with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for name in ['package.json','package-lock.json','tsconfig.json','remotion.config.ts','README.md','VALIDACAO.md','Narracao_AGEXA_55s.txt','Legendas_AGEXA_55s.json','Legendas_AGEXA_55s.srt','assets-manifest.json','.gitignore']:
  p=root/name
  if p.exists():z.write(p,'AGEXA_Remotion/'+name)
 for folder in ['src','public','blender','scripts']:
  for p in (root/folder).rglob('*'):
   if p.is_file() and not p.name.endswith('.blend1') and '__pycache__' not in p.parts:z.write(p,'AGEXA_Remotion/'+str(p.relative_to(root)))
with ZipFile(target) as z:
 assert z.testzip() is None
 print(target,round(target.stat().st_size/1024**2,1),'MiB',len(z.namelist()),'ficheiros; ZIP íntegro')
