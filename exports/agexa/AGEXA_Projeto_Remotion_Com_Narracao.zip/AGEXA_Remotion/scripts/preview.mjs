import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
import fs from 'node:fs';
const url=await bundle({entryPoint:'src/index.ts'});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'angle'}});
const comp=await selectComposition({serveUrl:url,id:'AGEXA-Anuncio-55s',puppeteerInstance:browser});
const frames=process.argv.slice(2).map(Number);
fs.mkdirSync('out/preview',{recursive:true});
for(const frame of (frames.length?frames:[110,285,445,520,590,680,730,765,840,1050,1290,1575])){
 await renderStill({serveUrl:url,composition:comp,frame,output:`out/preview/${String(frame).padStart(4,'0')}.png`,imageFormat:'png',scale:.5,puppeteerInstance:browser});
 console.log('Frame',frame,'ok');
}
await browser.close({silent:true});
