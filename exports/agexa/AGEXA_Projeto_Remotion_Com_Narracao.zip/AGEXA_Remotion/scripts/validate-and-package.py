"""Executar após o render; audita e prepara os três entregáveis principais."""
from pathlib import Path
import json,subprocess,shutil,hashlib
root=Path(__file__).resolve().parents[1]
subprocess.run(['python','scripts/verify-video.py'],cwd=root,check=True)
d=json.loads((root/'out/verificacao-tecnica.json').read_text())
play=root/'out/verificacao-reproducao.json'
p=json.loads(play.read_text()) if play.exists() else None
if p:
 assert p['duration']==55
 assert all(x['advanced'] and x['decodedFrames']>0 and x.get('seekCorrect',True) for x in p['samples'])
 assert p['mediaError'] is None
 report='Abertura em Chromium e reprodução confirmadas a 360 × 640. O tempo avançou e foram descodificados frames nos pontos 0 s, 24 s, 26 s, 43 s e 52 s. Sem erros de media.'
else:report='A reprodução no navegador ainda não foi registada. A descodificação integral por FFmpeg passou.'
sha=hashlib.sha256((root/'out/AGEXA_Anuncio_55s.mp4').read_bytes()).hexdigest()
text=f'''# Validação do anúncio Agexa

## Exportação e integridade

- Ficheiro: `{d['file']}`.
- Duração: **{d['duration']} segundos**, **{d['frames']} frames**, **30 fps**.
- Imagem: **1080 × 1920**, vertical 9:16, H.264, yuv420p.
- Áudio: AAC, estéreo, 48 kHz. **Narração neural em português de Portugal**, música e efeitos.
- Tamanho: {d['bytes']/1024**2:.2f} MiB.
- FFmpeg descodificou o ficheiro completo, vídeo e áudio, sem erros (`-xerror`).
- {report}
- SHA-256: `{sha}`.

## Revisão visual

Foram revistos enquadramentos em 360 × 640 e renders de amostra de todas as cenas. A cadeia conserva **Corte clássico → Mateus → 15:00**. A mesma camada de cartão passa da confirmação para a agenda. O contacto do fecho é **+258 84 671 1987**. As duas notificações e os toques acompanham as ações; existe silêncio antes da solução e uma mudança musical mais leve na confirmação.

As legendas foram medidas com a fonte Manrope a 44 px: no máximo duas linhas; largura máxima 697 px numa área interna de 764 px. Posição x=90–910, acima da zona inferior dos controlos sociais. Os passos e a agenda foram mantidos quase de frente para leitura.

O fecho estabiliza a partir de 49.1 s. A última legenda adicional termina em 50.85 s, deixando **4.15 s** finais apenas com o nome Agexa provisório, o símbolo de WhatsApp e as três linhas solicitadas.

## Narração e mistura

A voz masculina é `pt-PT-DuarteNeural`, uma voz neural genérica em português de Portugal. Não é a voz do Rogério nem uma imitação. O roteiro foi integralmente mantido, com 95 palavras. As fronteiras de palavras fornecidas pelo sintetizador foram usadas para alinhar os 18 trechos às legendas e às ações, numa única faixa contínua de 55 segundos. A fala termina em 53.25 s, deixando o contacto final em ecrã.

A faixa mono da voz mede **-16.78 LUFS** e **-2 dBTP**. A música baixa durante cada trecho de fala, com ataque de 65 ms e recuperação de 420 ms; os efeitos ficam a 72% do nível anterior. A voz ficou entre **17.3 e 26.3 dB** acima da música em RMS nos 18 trechos. O MP4 final mede **-14.01 LUFS**, com pico verdadeiro de **-1.51 dBTP**, sem clipping.

O Remotion renderizou a mistura das três faixas, e o áudio substituiu a mistura anterior no MP4 preservando os frames H.264. O hash do fluxo de vídeo antes e depois coincide: `923249783ca8261a35fdaafd0557c5cce12b5e53a54be176e879718107542fc0`. Os metadados do sintetizador confirmam a presença das 95 palavras do roteiro; a transcrição automática foi usada como verificação auxiliar.

## Materiais em falta

Não foram fornecidos o logótipo original, as capturas reais do produto nem a voz do Rogério. O MP4 é uma **versão ilustrativa**, com as telas identificadas em ecrã. O nome Agexa é texto provisório, não uma recriação do logótipo. Os pontos de substituição estão no README e em `src/settings.tsx`.

Não é possível confirmar a correspondência com a interface real sem receber as capturas. A voz neural está incorporada e a música e os efeitos continuam em faixas separadas. A eventual gravação do Rogério pode substituir a voz atual em `src/settings.tsx`.

## Projeto editável

TypeScript passou (`npm run check`). As seis cenas estão registadas no Remotion Studio e a prévia foi aberta. Incluem-se fontes, texturas, scripts de síntese e seis ficheiros Blender editáveis com as imagens necessárias incorporadas. O ZIP é verificado com `testzip()` durante a embalagem.
'''
(root/'VALIDACAO.md').write_text(text)
out=root.parent/'entrega';out.mkdir(exist_ok=True)
for name in ['AGEXA_Anuncio_55s.mp4']:
 shutil.copy2(root/'out'/name,out/name)
shutil.copy2(root/'out/AGEXA_Anuncio_55s.mp4',out/'AGEXA_Anuncio_55s_Com_Narracao.mp4')
shutil.copy2(root/'public/audio/narracao.wav',out/'Narracao_AGEXA_55s.wav')
for name in ['Narracao_AGEXA_55s.txt','Legendas_AGEXA_55s.srt','VALIDACAO.md']:
 shutil.copy2(root/name,out/name)
for name in ['Storyboard_AGEXA.jpg']:
 if (root/'out'/name).exists():shutil.copy2(root/'out'/name,out/name)
subprocess.run(['python','scripts/package-project.py'],cwd=root,check=True)
shutil.copy2(out/'AGEXA_Projeto_Remotion.zip',out/'AGEXA_Projeto_Remotion_Com_Narracao.zip')
print('ENTREGA CONCLUÍDA',out)
