"""Verificação objetiva do MP4 entregue. Executar depois do render."""
from pathlib import Path
import json,subprocess,sys
p=Path(sys.argv[1] if len(sys.argv)>1 else 'out/AGEXA_Anuncio_55s.mp4')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)],text=True))
v=next(s for s in probe['streams'] if s['codec_type']=='video')
a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert v['codec_name']=='h264';assert (v['width'],v['height'])==(1080,1920)
assert v['r_frame_rate']=='30/1';assert v['pix_fmt']=='yuv420p'
assert int(v['nb_frames'])==1650;assert abs(float(probe['format']['duration'])-55)<.05
assert a['codec_name']=='aac';assert int(a['sample_rate'])==48000;assert a['channels']==2
decode=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(p),'-f','null','-'],capture_output=True,text=True)
assert decode.returncode==0,decode.stderr
summary={'file':p.name,'duration':probe['format']['duration'],'frames':v['nb_frames'],'fps':v['r_frame_rate'],'dimensions':[v['width'],v['height']],'video':v['codec_name'],'pixel_format':v['pix_fmt'],'audio':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels'],'bytes':p.stat().st_size,'full_decode':'passed'}
Path('out/verificacao-tecnica.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
