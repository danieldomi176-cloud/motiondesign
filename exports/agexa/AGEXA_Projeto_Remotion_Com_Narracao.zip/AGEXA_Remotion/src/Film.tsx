import React from 'react';
import {Sequence,useVideoConfig} from 'remotion';
import {Pain} from './scenes/Pain';
import {Solution} from './scenes/Solution';
import {Booking} from './scenes/Booking';
import {Business} from './scenes/Business';
import {Sectors} from './scenes/Sectors';
import {CallToAction} from './scenes/CallToAction';
import {Soundtrack} from './Soundtrack';

export const Film=()=>{
 const {fps}=useVideoConfig();
 return <>
  <Sequence name="01 · A dor" from={0} durationInFrames={6*fps} premountFor={fps}><Pain/></Sequence>
  <Sequence name="02 · Um link do teu negócio" from={6*fps} durationInFrames={7*fps} premountFor={fps}><Solution/></Sequence>
  <Sequence name="03 · Cliente faz a marcação" from={13*fps} durationInFrames={12*fps} premountFor={fps}><Booking/></Sequence>
  <Sequence name="04 · A mesma marcação chega à agenda" from={25*fps} durationInFrames={13*fps} premountFor={fps}><Business/></Sequence>
  <Sequence name="05 · Para quem serve" from={38*fps} durationInFrames={10*fps} premountFor={fps}><Sectors/></Sequence>
  <Sequence name="06 · Pede uma demonstração" from={48*fps} durationInFrames={7*fps} premountFor={fps}><CallToAction/></Sequence>
  <Soundtrack/>
 </>;
};
