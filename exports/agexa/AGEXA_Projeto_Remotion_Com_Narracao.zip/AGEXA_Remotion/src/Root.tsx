import React from 'react';
import {Composition,Folder} from 'remotion';
import {Film} from './Film';
import {Pain} from './scenes/Pain';
import {Solution} from './scenes/Solution';
import {Booking} from './scenes/Booking';
import {Business} from './scenes/Business';
import {Sectors} from './scenes/Sectors';
import {CallToAction} from './scenes/CallToAction';
import {Soundtrack} from './Soundtrack';
export const Root=()=> <>
 <Composition id="AGEXA-Anuncio-55s" component={Film} width={1080} height={1920} fps={30} durationInFrames={1650}/>
 <Folder name="Cenas">
  <Composition id="01-Dor" component={Pain} width={1080} height={1920} fps={30} durationInFrames={180}/>
  <Composition id="02-Solucao" component={Solution} width={1080} height={1920} fps={30} durationInFrames={210}/>
  <Composition id="03-Marcacao" component={Booking} width={1080} height={1920} fps={30} durationInFrames={360}/>
  <Composition id="04-Agenda" component={Business} width={1080} height={1920} fps={30} durationInFrames={390}/>
  <Composition id="05-Sectores" component={Sectors} width={1080} height={1920} fps={30} durationInFrames={300}/>
  <Composition id="06-CTA" component={CallToAction} width={1080} height={1920} fps={30} durationInFrames={210}/>
 </Folder>
 <Folder name="Som">
  <Composition id="AGEXA-Mistura-Com-Voz" component={Soundtrack} width={1080} height={1920} fps={30} durationInFrames={1650}/>
 </Folder>
</>;
