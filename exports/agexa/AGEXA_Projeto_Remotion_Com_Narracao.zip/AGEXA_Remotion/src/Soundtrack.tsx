import React from 'react';
import {Audio} from '@remotion/media';
import {staticFile,useVideoConfig} from 'remotion';
import {SETTINGS} from './settings';

// A mesma mistura é usada no anúncio e na composição de áudio independente.
export const Soundtrack=()=>{
 const {fps}=useVideoConfig();
 return <>
  <Audio name="Música original · ducking da narração" src={staticFile(SETTINGS.narrationFile?'audio/musica_voz.wav':'audio/musica.wav')} volume={1} premountFor={fps}/>
  <Audio name="Notificações, toques e transições" src={staticFile('audio/efeitos.wav')} volume={SETTINGS.narrationFile?.length?0.72:1} premountFor={fps}/>
  {SETTINGS.narrationFile&&<Audio name="Narração contínua" src={staticFile(SETTINGS.narrationFile)} volume={1} premountFor={fps}/>}
 </>;
};
