import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {BasicCaptions} from './basic-captions.element';

export const C={ink:'#09090e',graphite:'#17151e',purple:'#a77aff',white:'#f7f4fc',muted:'#aaa3ba'};
export const BOOKING={service:'Corte clássico',professional:'Mateus',time:'15:00',client:'Cliente Demo',business:'Barbearia Demo',whatsapp:'+258 84 671 1987'} as const;
export const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export const ease=Easing.bezier(.16,1,.3,1);
export const k=(f:number,a:number,b:number,x=0,y=1)=>interpolate(f,[a,b],[x,y],{...clamp,easing:ease});

export const GlobalStyle=()=> <style>{`
@font-face{font-family:Manrope;src:url('${staticFile('fonts/manrope-latin-400-normal.woff2')}');font-weight:400}
@font-face{font-family:Manrope;src:url('${staticFile('fonts/manrope-latin-600-normal.woff2')}');font-weight:600}
@font-face{font-family:Manrope;src:url('${staticFile('fonts/manrope-latin-700-normal.woff2')}');font-weight:700}
@font-face{font-family:Manrope;src:url('${staticFile('fonts/manrope-latin-800-normal.woff2')}');font-weight:800}
*{box-sizing:border-box} .safe-captions>div>div{font-family:Manrope,sans-serif!important;font-size:44px!important;line-height:1.35!important;font-weight:600!important;background:rgba(15,13,21,.92)!important;border:1px solid rgba(214,192,255,.16);border-radius:20px;padding:18px 26px!important;max-width:820px}
`}</style>;

export const Scene:React.FC<React.PropsWithChildren>=({children})=><AbsoluteFill style={{fontFamily:'Manrope,sans-serif',color:C.white,overflow:'hidden'}}><GlobalStyle/>{children}</AbsoluteFill>;

export const Background=({offset=0,quiet=false}:{offset?:number;quiet?:boolean})=>{
 const f=useCurrentFrame()+offset;
 return <AbsoluteFill style={{background:C.ink,overflow:'hidden'}}>
  <AbsoluteFill style={{background:'radial-gradient(ellipse at 50% 41%,#231a32 0%,#111017 42%,#08090d 80%)'}}/>
  <div style={{position:'absolute',width:960,height:960,borderRadius:'50%',left:80+Math.sin(f/180)*45,top:400+Math.cos(f/210)*60,background:quiet?'radial-gradient(circle,rgba(112,58,210,.13),transparent 66%)':'radial-gradient(circle,rgba(134,73,255,.22),transparent 68%)',filter:'blur(30px)'}}/>
  <div style={{position:'absolute',left:-220,top:700,width:1500,height:1500,borderRadius:'50%',border:'1px solid rgba(165,125,232,.12)',transform:`rotateX(67deg) rotateZ(${-30+f/120}deg)`,boxShadow:'0 0 90px rgba(112,66,177,.06), inset 0 0 70px rgba(120,70,220,.04)'}}/>
  {!quiet&&<><div style={{position:'absolute',left:-350,top:430,width:700,height:1060,borderRadius:'50%',border:'2px solid rgba(172,137,230,.065)',transform:`rotate(-30deg) translateY(${Math.sin(f/90)*12}px)`}}/><div style={{position:'absolute',left:985,top:130,width:1,height:1470,background:'linear-gradient(transparent,rgba(197,174,240,.12),transparent)'}}/></>}
 </AbsoluteFill>;
};

export const Eyebrow=({children}:{children:React.ReactNode})=><div style={{position:'absolute',left:90,top:108,fontSize:25,fontWeight:700,letterSpacing:4,color:C.purple,display:'flex',alignItems:'center',gap:17}}><span style={{width:8,height:8,borderRadius:4,background:C.purple,boxShadow:'0 0 18px #a77aff'}}/>{children}</div>;

export const Heading=({children,size=84,top=177}:{children:React.ReactNode;size?:number;top?:number})=>{
 const f=useCurrentFrame();return <div style={{position:'absolute',left:90,top,width:840,fontSize:size,fontWeight:800,lineHeight:1.12,letterSpacing:-4,opacity:k(f,0,12),translate:`0 ${k(f,0,16,22,0)}px`}}>{children}</div>;
};

export const Glass:React.FC<React.PropsWithChildren<{style?:React.CSSProperties;accent?:boolean}>>=({children,style,accent=false})=><div style={{position:'absolute',borderRadius:34,background:accent?'linear-gradient(135deg,rgba(170,123,255,.3),rgba(66,38,103,.65))':'linear-gradient(135deg,rgba(231,221,255,.15),rgba(33,27,44,.72) 53%,rgba(119,88,158,.2))',border:accent?'1.6px solid rgba(197,164,255,.72)':'1.5px solid rgba(223,209,255,.28)',boxShadow:'inset 0 1px 1px rgba(255,255,255,.38),inset 0 -1px 1px rgba(193,159,242,.16),0 18px 55px rgba(0,0,0,.38)',backdropFilter:'blur(22px) saturate(1.2)',...style}}>{children}</div>;

export const Reflection=({f=0}:{f?:number})=><div style={{pointerEvents:'none',position:'absolute',inset:0,borderRadius:'inherit',overflow:'hidden'}}><div style={{position:'absolute',top:-300,left:-200+k(f,0,70,0,1100),width:150,height:1000,rotate:'-30deg',background:'linear-gradient(90deg,transparent,rgba(255,255,255,.08),transparent)'}}/></div>;

export const Phone=({stage='idle',style}:{stage?:string;style?:React.CSSProperties})=><Img src={staticFile(`3d/phone-${stage}.png`)} style={{position:'absolute',left:200,top:330,width:620,height:1205.56,filter:'drop-shadow(0px 30px 38px rgba(0,0,0,.48))',...style}}/>;

export const DemoNote=({top=1498}:{top?:number})=><div style={{position:'absolute',left:90,top,width:820,textAlign:'center',color:'#9890a8',fontSize:24,letterSpacing:.2}}>Interface ilustrativa · Dados de demonstração</div>;

export const Tap=({x,y,at}:{x:number;y:number;at:number})=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f-at*fps;
 if(t<0||t>fps*.85)return null;
 return <div style={{position:'absolute',left:x,top:y,translate:'-50% -50%',width:86,height:86,borderRadius:90,border:'3px solid #cfb5ff',background:'rgba(171,121,255,.1)',scale:k(t,0,25,.25,1.6),opacity:interpolate(t,[0,5,22,26],[0,1,.6,0],clamp),boxShadow:'0 0 32px rgba(172,123,255,.3)'}}><div style={{position:'absolute',width:15,height:15,left:32,top:32,borderRadius:10,background:'white'}}/></div>;
};

export const Tick=({size=30}:{size?:number})=><svg width={size} height={size} viewBox="0 0 32 32"><circle cx="16" cy="16" r="16" fill={C.purple}/><path d="m9 16 5 5 10-11" stroke="#180f26" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>;

// One shared ticket is lifted from the phone and docked in the business calendar.
export const BookingTicket=({style,compact=false,focus=0}:{style?:React.CSSProperties;compact?:boolean;focus?:number})=><Glass accent style={{left:281,top:930,width:460,height:306,padding:'25px 28px',...style}}>
 <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',fontSize:20,lineHeight:'24px',letterSpacing:1.3,color:'#d9c7f5',fontWeight:700}}>MARCAÇÃO CONFIRMADA<Tick size={24}/></div>
 <div style={{display:'flex',alignItems:'baseline',gap:15,marginTop:8,height:compact?58:64}}><span style={{fontSize:compact?54:64,lineHeight:1,fontWeight:800,color:focus===2?'white':C.white,letterSpacing:-2}}>{BOOKING.time}</span><span style={{fontSize:23,lineHeight:1,color:'#c6b9d9'}}>Hoje</span></div>
 <div style={{fontSize:compact?38:40,lineHeight:compact?'42px':'44px',fontWeight:800,marginTop:3,letterSpacing:-1,color:focus===3?'#e2ceff':C.white}}>{BOOKING.service}</div>
 <div style={{fontSize:compact?30:34,lineHeight:compact?'34px':'38px',marginTop:3,color:'#e2d5f6'}}>{BOOKING.professional}<span style={{fontSize:compact?23:25,color:'#aa9abb'}}> · Profissional</span></div>
 {!compact&&<div style={{fontSize:25,lineHeight:'28px',marginTop:4,color:focus===1?'#fff':'#c0b3d0'}}>{BOOKING.client}</div>}
 <Reflection f={focus?120:0}/>
</Glass>;

export const Calendar=({style,showTicket=true,focus=0,compact=false}:{style?:React.CSSProperties;showTicket?:boolean;focus?:number;compact?:boolean})=><div style={{position:'absolute',left:90,top:550,width:820,height:832,transformOrigin:'50% 45%',...style}}>
 <Glass style={{inset:0,borderRadius:38,background:'linear-gradient(140deg,rgba(51,43,66,.96),rgba(21,18,29,.94))'}}>
  <div style={{height:112,display:'flex',alignItems:'center',padding:'0 32px',borderBottom:'1px solid #494052',gap:12}}><span style={{fontSize:36,fontWeight:800,letterSpacing:-1}}>Agexa <span style={{fontWeight:400,color:'#b5a8c9'}}>Business</span></span><div style={{marginLeft:'auto',fontSize:19,color:'#bea6df',background:'#33243f',border:'1px solid #614877',borderRadius:10,padding:'8px 12px'}}>DEMO</div></div>
  <div style={{position:'absolute',top:141,left:32,fontSize:51,fontWeight:800,letterSpacing:-2}}>Agenda</div>
  <div style={{position:'absolute',top:211,left:32,fontSize:30,color:'#b5a7c6'}}>Hoje · Dia de demonstração</div>
  <div style={{position:'absolute',top:274,left:168,fontSize:32,fontWeight:700,color:'#ddd0f0'}}>{BOOKING.professional}</div>
  <div style={{position:'absolute',left:132,top:268,bottom:28,width:1,background:'#54445f'}}/>
  <div style={{position:'absolute',left:32,top:342,fontSize:28,color:'#9d8fae'}}>14h</div>
  <div style={{position:'absolute',left:32,top:482,fontSize:28,color:C.purple,fontWeight:700}}>15h</div>
  <div style={{position:'absolute',left:32,top:777,fontSize:28,color:'#9d8fae'}}>16h</div>
  <div style={{position:'absolute',left:132,right:30,top:331,height:1,background:'#3c3248'}}/>
  <div style={{position:'absolute',left:132,right:30,top:466,height:1,background:'#5b3d7c'}}/>
  <div style={{position:'absolute',left:132,right:30,top:760,height:1,background:'#3c3248'}}/>
 </Glass>
 {showTicket&&<BookingTicket compact={compact} focus={focus} style={{left:158,top:476,width:630,height:compact?222:274,padding:'22px 28px'}}/>}
</div>;

export {BasicCaptions};
