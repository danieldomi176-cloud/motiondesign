import React from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import {Background,BasicCaptions,BookingTicket,C,DemoNote,Eyebrow,Heading,k,Phone,Scene,Tap} from '../design';

export const Booking=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const stage=t<2.5?'service':t<5?'professional':t<7.7?'time':t<10.4?'review':'confirmed';
 const index=t<2.5?0:t<5?1:t<7.7?2:3;
 return <Scene><Background offset={390}/><Eyebrow>DO LADO DO CLIENTE</Eyebrow><Heading size={79}>{stage==='confirmed'?<>Marcação confirmada.</>:<>Marca em 4 passos.</>}</Heading>
  <div style={{position:'absolute',left:123,top:293,width:760,display:'flex',alignItems:'center',gap:15}}>{['Serviço','Profissional','Horário','Confirmar'].map((label,i)=><React.Fragment key={label}>{i>0&&<span style={{color:'#655575',fontSize:25}}>→</span>}<span style={{color:i<=index?C.purple:'#7d718c',fontSize:25,fontWeight:i===index?800:600}}>{label}</span></React.Fragment>)}</div>
  <Phone stage={stage}/>
  <Tap x={703} y={826} at={1.5}/><Tap x={705} y={834} at={4}/><Tap x={626} y={963} at={6.2}/><Tap x={685} y={1335} at={10.1}/>
  {stage==='confirmed'&&<BookingTicket style={{opacity:k(f,10.4*fps,10.65*fps),scale:k(f,10.4*fps,10.85*fps,.94,1)}}/>}
  <DemoNote/>
  <div className="safe-captions" style={{position:'absolute',left:90,top:1570}}><BasicCaptions width={820} premountFor={fps} combineTokensWithinMilliseconds={0} captions={[
   {text:'Escolhe o serviço,',startMs:0,endMs:2500,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'o profissional',startMs:2500,endMs:5000,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'e uma hora livre.',startMs:5000,endMs:7700,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'Depois confirma a marcação.',startMs:7700,endMs:11900,timestampMs:null,confidence:null,pageBreakAfter:true},
  ]}/></div>
 </Scene>;
};
