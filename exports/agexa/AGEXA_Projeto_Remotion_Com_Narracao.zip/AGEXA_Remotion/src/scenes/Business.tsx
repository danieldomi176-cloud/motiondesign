import React from 'react';
import {useCurrentFrame,useVideoConfig,interpolate} from 'remotion';
import {Background,BasicCaptions,BookingTicket,Calendar,clamp,DemoNote,Eyebrow,Heading,k,Phone,Scene} from '../design';

export const Business=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const q=k(f,.1*fps,1.5*fps);
 const focus=f<5*fps?0:f<7.5*fps?1:f<9.5*fps?2:3;
 return <Scene><Background offset={750}/><Eyebrow>DO LADO DO NEGÓCIO</Eyebrow><Heading size={82}>A mesma marcação.<br/><span style={{color:'#b58bff'}}>Na tua agenda.</span></Heading>
  {f<1.5*fps&&<Phone stage="confirmed" style={{opacity:1-k(f,.1*fps,1.05*fps),translate:`${k(f,.1*fps,1.4*fps,0,-200)}px ${k(f,.1*fps,1.4*fps,0,80)}px`,transform:`perspective(1800px) rotateY(${q*-25}deg)`}}/>}
  <Calendar showTicket={false} style={{opacity:k(f,.45*fps,1.2*fps),scale:k(f,.45*fps,1.6*fps,.9,1)}}/>
  <BookingTicket focus={focus} style={{left:281+(248-281)*q,top:930+(1026-930)*q,width:460+(630-460)*q,height:306+(274-306)*q,padding:`${25-3*q}px 28px`,transform:`perspective(1200px) rotateY(${interpolate(f,[0,.55*fps,1.5*fps],[0,-22,0],clamp)}deg) rotateZ(${interpolate(f,[0,.5*fps,1.5*fps],[0,-3,0],clamp)}deg)`,boxShadow:`inset 0 1px 1px #e1c9ff77,0 ${24+Math.sin(q*Math.PI)*55}px ${60+Math.sin(q*Math.PI)*40}px #0008`}}/>
  {f>2*fps&&<div style={{position:'absolute',left:90,top:1430,width:820,display:'flex',justifyContent:'center',gap:15,opacity:k(f,2*fps,2.4*fps)}}>{['Quem vem','A que horas','Qual serviço'].map((label,i)=><div key={label} style={{border:`1px solid ${focus===i+1?'#ab7df1':'#39313f'}`,borderRadius:18,padding:'13px 20px',fontSize:25,color:focus===i+1?'#e8d9ff':'#9989ad',background:focus===i+1?'#30213f':'#17131e'}}>{label}</div>)}</div>}
  <DemoNote top={1510}/>
  <div className="safe-captions" style={{position:'absolute',left:90,top:1570}}><BasicCaptions width={820} premountFor={fps} combineTokensWithinMilliseconds={0} captions={[
   {text:'Do teu lado, essa marcação\naparece na agenda.',startMs:0,endMs:4500,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'Sabes quem vem,',startMs:4500,endMs:7500,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'a que horas',startMs:7500,endMs:9500,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'e qual serviço pediu.',startMs:9500,endMs:12800,timestampMs:null,confidence:null,pageBreakAfter:true},
  ]}/></div>
 </Scene>;
};
