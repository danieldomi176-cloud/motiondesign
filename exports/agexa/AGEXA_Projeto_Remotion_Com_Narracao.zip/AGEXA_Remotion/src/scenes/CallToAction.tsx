import React from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import {Background,BasicCaptions,BOOKING,C,k,Scene} from '../design';
import {BrandMark} from '../settings';

export const CallToAction=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 return <Scene><Background offset={1440} quiet/>
  <div style={{position:'absolute',left:80,top:420,width:850,textAlign:'center',opacity:k(f,0,.7*fps),translate:`0 ${k(f,0,.7*fps,28,0)}px`}}><BrandMark/></div>
  <div style={{position:'absolute',left:80,top:829,width:850,textAlign:'center',opacity:k(f,.4*fps,1.1*fps),translate:`0 ${k(f,.4*fps,1.1*fps,30,0)}px`}}>
   <div style={{fontSize:64,fontWeight:800,letterSpacing:-2,whiteSpace:'nowrap'}}>Pede uma demonstração</div>
   <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:17,marginTop:47}}><svg width="49" height="49" viewBox="0 0 32 32" fill="none"><path d="M27 15.5a11.5 11.5 0 0 1-17.5 9.9L4 27l1.6-5.4A11.5 11.5 0 1 1 27 15.5Z" stroke={C.purple} strokeWidth="2"/><path d="M11 9c-1 0-2 1-2 3 0 4 7 11 11 10 2-.5 3-2 2-3l-3-1.5-1.5 1.5c-2-1-4-3-4.5-4.5l1-1.5L12 9Z" fill={C.purple}/></svg><span style={{fontSize:63,fontWeight:700,letterSpacing:-1,color:'#c9aaff',whiteSpace:'nowrap'}}>{BOOKING.whatsapp}</span></div>
   <div style={{fontSize:44,fontWeight:400,marginTop:74,color:'#d3c8e2',whiteSpace:'nowrap',letterSpacing:-.9}}>A organização que trabalha por ti.</div>
  </div>
  <div className="safe-captions" style={{position:'absolute',left:90,top:1540}}><BasicCaptions width={820} premountFor={fps} combineTokensWithinMilliseconds={0} captions={[
   {text:'Queres ver como ficaria\nno teu negócio?',startMs:0,endMs:2850,timestampMs:null,confidence:null,pageBreakAfter:true},
  ]}/></div>
 </Scene>;
};
