import React from 'react';
import {Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Background, BasicCaptions, C, clamp, Eyebrow, Glass, Heading, k, Phone, Scene} from '../design';

export const Pain=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 return <Scene><Background/><Eyebrow>O DIA A DIA DO TEU NEGÓCIO</Eyebrow>
  <Heading size={87}>{f<4.2*fps?<>Estás a atender.</>:<>Quem responde?</>}</Heading>
  <Phone stage={f<9?'angle':'idle'} style={{translate:`0 ${k(f,0,20,55,0)}px`,rotate:`${k(f,0,24,-5,0)}deg`}}/>
  <Glass style={{left:100,top:622,width:730,height:150,padding:'30px 34px',opacity:k(f,.35*fps,.6*fps),translate:`${k(f,.35*fps,.8*fps,-140,0)}px 0`}}><div style={{fontSize:20,color:'#a89bbd',letterSpacing:2,fontWeight:700}}>MENSAGEM SIMULADA</div><div style={{fontSize:44,fontWeight:600,marginTop:10}}>Tens vaga hoje?</div></Glass>
  <Glass style={{left:160,top:810,width:700,height:150,padding:'30px 34px',opacity:k(f,1.6*fps,1.85*fps),translate:`${k(f,1.6*fps,2.1*fps,150,0)}px 0`}}><div style={{fontSize:20,color:'#a89bbd',letterSpacing:2,fontWeight:700}}>MENSAGEM SIMULADA</div><div style={{fontSize:42,fontWeight:600,marginTop:10}}>Quem me pode atender?</div></Glass>
  <Glass accent style={{left:100,top:1005,width:760,height:188,padding:'30px 34px',opacity:k(f,2.9*fps,3.1*fps),translate:`${k(f,2.9*fps,3.35*fps,-150,0)}px 0`}}><div style={{fontSize:20,color:'#d1bbed',letterSpacing:2,fontWeight:700}}>MENSAGEM SIMULADA</div><div style={{fontSize:44,fontWeight:700,marginTop:10}}>Posso marcar às 15h?</div><div style={{fontSize:24,color:'#baa2d7',marginTop:7}}>Por responder…</div></Glass>
  <div style={{position:'absolute',left:678,top:354,width:239,height:239,opacity:k(f,3.25*fps,3.55*fps),scale:k(f,3.25*fps,3.8*fps,.7,1)}}>
   <Img src={staticFile('3d/clock.png')} style={{width:'100%',height:'100%'}}/>
   <div style={{position:'absolute',left:'50%',top:'50%',width:5,height:66,marginTop:-66,borderRadius:4,background:'#d6c7ef',transformOrigin:'50% 100%',rotate:`${interpolate(f,[3.2*fps,6*fps],[0,540],clamp)}deg`,boxShadow:'2px 3px 5px #000'}}/>
   <div style={{position:'absolute',left:'50%',top:'50%',width:7,height:44,marginTop:-44,borderRadius:5,background:C.purple,transformOrigin:'50% 100%',rotate:`${90+f*.2}deg`}}/>
  </div>
  <div className="safe-captions" style={{position:'absolute',left:90,top:1570}}><BasicCaptions width={820} premountFor={fps} combineTokensWithinMilliseconds={0} captions={[
   {text:'Estás a atender um cliente.',startMs:0,endMs:1700,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'Entretanto, três pessoas\nperguntam se tens vaga.',startMs:1700,endMs:4400,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'Quem responde?',startMs:4400,endMs:5800,timestampMs:null,confidence:null,pageBreakAfter:true},
  ]}/></div>
 </Scene>;
};
