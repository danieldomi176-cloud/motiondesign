import React from 'react';
import {Img,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Background,BasicCaptions,Calendar,DemoNote,Eyebrow,Glass,Heading,k,Scene} from '../design';

const Sector=({asset,label,x,y,at}:{asset:string;label:string;x:number;y:number;at:number})=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();return <div style={{position:'absolute',left:x,top:y,width:220,height:245,opacity:k(f,at*fps,(at+.3)*fps),translate:`0 ${k(f,at*fps,(at+.55)*fps,70,0)+Math.sin((f-at*fps)/35)*3}px`,rotate:`${k(f,at*fps,(at+.65)*fps,-12,0)}deg`,scale:k(f,at*fps,(at+.5)*fps,.7,1)}}>
  <Glass style={{left:4,top:20,width:210,height:188,borderRadius:40,background:'linear-gradient(130deg,#39304465,#16121ee0)',transform:'perspective(900px) rotateX(12deg)'}}/>
  <Img src={staticFile(`3d/${asset}.png`)} style={{position:'absolute',left:-5,top:-18,width:235,height:235,filter:'drop-shadow(0 16px 14px #0006)'}}/>
  <div style={{position:'absolute',top:215,left:-15,width:250,textAlign:'center',fontSize:31,fontWeight:700,color:'#ddcdee'}}>{label}</div>
 </div>;
};

export const Sectors=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 return <Scene><Background offset={1140}/><Eyebrow>PARA NEGÓCIOS COM HORA MARCADA</Eyebrow><Heading size={84}>Uma agenda.<br/>Vários negócios.</Heading>
  <Calendar compact style={{top:550+k(f,0,.7*fps,0,70),scale:1-k(f,0,.7*fps,0,.06),transformOrigin:'50% 0%'}}/>
  <Sector asset="clipper" label="Barbearia" x={108} y={361} at={.35}/>
  <Sector asset="dryer" label="Salão" x={676} y={361} at={1.6}/>
  <Sector asset="towel" label="Spa" x={108} y={1290} at={2.55}/>
  <Sector asset="consultation" label="Clínica" x={676} y={1290} at={3.25}/>
  <DemoNote top={1510}/>
  <div className="safe-captions" style={{position:'absolute',left:90,top:1570}}><BasicCaptions width={820} premountFor={fps} combineTokensWithinMilliseconds={0} captions={[
   {text:'Tens uma barbearia, um salão,',startMs:0,endMs:2400,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'um spa ou uma clínica?',startMs:2400,endMs:4100,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'Podes organizar os teus serviços,',startMs:4100,endMs:6800,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'profissionais e horários\nno mesmo painel.',startMs:6800,endMs:9800,timestampMs:null,confidence:null,pageBreakAfter:true},
  ]}/></div>
 </Scene>;
};
