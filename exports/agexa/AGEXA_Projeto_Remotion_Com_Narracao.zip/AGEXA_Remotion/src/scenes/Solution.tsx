import React from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import {Background,BasicCaptions,DemoNote,Eyebrow,Glass,Heading,k,Phone,Reflection,Scene,Tap} from '../design';

export const Solution=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();
 return <Scene><Background offset={180}/><Eyebrow>AGEXA / DO LADO DO CLIENTE</Eyebrow><Heading size={83}>Partilha o teu link.</Heading>
  <Phone stage={f<3.5*fps?'link':'service'}/>
  {f<.7*fps&&<Glass accent style={{left:100,top:1005,width:760,height:188,padding:'45px 34px',translate:`${k(f,0,.7*fps,0,-1200)}px 0`}}><div style={{fontSize:44,fontWeight:700}}>Posso marcar às 15h?</div></Glass>}
  <Glass style={{left:105,top:1075,width:730,height:155,padding:'27px 35px',opacity:k(f,.3*fps,.7*fps)*(1-k(f,3.25*fps,3.6*fps)),translate:`${k(f,.2*fps,.9*fps,1100,0)}px 0`,overflow:'hidden'}}>
   <div style={{fontSize:24,color:'#c4acde',fontWeight:700,letterSpacing:2}}>LINK DO TEU NEGÓCIO</div><div style={{fontSize:39,fontWeight:700,marginTop:12}}>Página de marcação <span style={{float:'right',color:'#c3a2ff'}}>↗</span></div><Reflection f={f}/>
  </Glass>
  <Tap x={685} y={1335} at={2.7}/>
  {f>=3.5*fps&&<Glass style={{left:627,top:1180,width:235,height:94,padding:'20px 22px',opacity:k(f,3.5*fps,3.8*fps),background:'linear-gradient(135deg,#3c2c53dd,#1c1724ee)'}}><div style={{fontSize:31,fontWeight:700,color:'#d5baff'}}>Link aberto ✓</div></Glass>}
  <DemoNote/>
  <div className="safe-captions" style={{position:'absolute',left:90,top:1570}}><BasicCaptions width={820} premountFor={fps} combineTokensWithinMilliseconds={0} captions={[
   {text:'Com o Agexa, partilhas\num link do teu negócio.',startMs:0,endMs:3000,timestampMs:null,confidence:null,pageBreakAfter:true},
   {text:'O cliente abre-o e vê\nos horários disponíveis.',startMs:3000,endMs:6900,timestampMs:null,confidence:null,pageBreakAfter:true},
  ]}/></div>
 </Scene>;
};
