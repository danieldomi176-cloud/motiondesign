import React from 'react';
import {Img,staticFile} from 'remotion';
// Nenhum logótipo foi fornecido. O nome abaixo é TEXTO PROVISÓRIO, não um logo reconstituído.
// Copiar o original para public/brand/logo-original.png e definir logoFile abaixo.
export const SETTINGS:{logoFile:string|null;narrationFile:string|null}={logoFile:null,narrationFile:'audio/narracao.wav'};
export const BrandMark=()=>SETTINGS.logoFile?<Img src={staticFile(SETTINGS.logoFile)} style={{width:660,height:260,objectFit:'contain'}}/>:<div style={{fontSize:155,fontWeight:800,letterSpacing:-10,color:'#f6f1ff',lineHeight:1.5,textShadow:'0 0 100px #8556be35'}}>Agexa</div>;
